<?php

$data = [
    "teamA" => 0,
    "teamB" => 0,
    "gameOver" => false,
    "maxScore" => 21
];

file_put_contents(
    "current_game.json",
    json_encode($data, JSON_PRETTY_PRINT),
    LOCK_EX
);

echo json_encode($data);
?>

