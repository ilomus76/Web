// score_board.js (기초 버전)

let teamA = 0;
let teamB = 0;
let gameOver = false;
let maxScore = 21;
let currentGame = 1;

// DOM
let scoreA, scoreB, statusBox, gameNo;

// 시작
window.addEventListener("DOMContentLoaded", init);

function init() {
    scoreA = document.querySelector("#team_A .score");
    scoreB = document.querySelector("#team_B .score");
    statusBox = document.getElementById("game_status");
    gameNo = document.getElementById("game_no");

    // 점수 클릭 (증가)
    document.querySelector("#team_A .score_area").addEventListener("click", () => {
        if (gameOver) return;

        teamA++;
        checkWin();
        updateUI();
    });

    document.querySelector("#team_B .score_area").addEventListener("click", () => {
        if (gameOver) return;

        teamB++;
        checkWin();
        updateUI();
    });

    // 감소 버튼
    document.getElementById("teamA_minus").onclick = () => {
        if (gameOver) return;
        if (teamA > 0) teamA--;
        updateUI();
    };

    document.getElementById("teamB_minus").onclick = () => {
        if (gameOver) return;
        if (teamB > 0) teamB--;
        updateUI();
    };

    // RESET
    document.getElementById("reset_score").onclick = resetGame;

    // 다음 경기
    document.getElementById("next_game").onclick = nextGame;

    // 점수 설정
    document.getElementById("max_score").addEventListener("change", function () {
        maxScore = Number(this.value);
        resetGame();
    });

    updateUI();
}

////////////////////(승리 판단)//////////////////////////////////////////

function checkWin() {
    if (gameOver) return;

    if ((teamA >= maxScore || teamB >= maxScore) &&
        Math.abs(teamA - teamB) >= 2) {

        gameOver = true;

        statusBox.innerText =
            (teamA > teamB ? "Team A WIN!" : "Team B WIN!");

        statusBox.style.color = "red";
    }
}


////////////////////// UI 업데이트//////////////////////////////////////


function updateUI() {
    scoreA.innerText = teamA;
    scoreB.innerText = teamB;

    if (!gameOver) {
        statusBox.innerText = "경기 중";
        statusBox.style.color = "green";
    }

    if (teamA === 0 && teamB === 0 && !gameOver) {
        statusBox.innerText = "경기 시작전";
        statusBox.style.color = "gray";
    }

    gameNo.innerText = currentGame;
}


////////////////////// Reset 기능//////////////////////////////////////
function resetGame() {
    teamA = 0;
    teamB = 0;
    gameOver = false;

    updateUI();  // 위쪽에 있음. 
}


///////////////////// 다음 경기 //////////////////////////////////////
function nextGame() {
    currentGame++;
    resetGame();   // 바로위에 있음
}
